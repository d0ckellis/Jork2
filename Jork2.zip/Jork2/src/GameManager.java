/**
 * A class to store the various strings to be printed into the console.
 * @author andyh
 * @version 1.0
 */
public class GameManager {
    public String startUp = "Booting...\nWelcome to Jork!\nA text-based Role-Playing game where you choose your journey!";
    public String gameOver = "Your journey has now come to an end...";
    public String namePrompt = "What's our hero's name?";
    public String perkPrompt = "";

    /**
     * Empties the visible {@code Console} after every action
     */
    public static void consoleWipe() {
        System.out.println("Console cleared!");
    }
}
