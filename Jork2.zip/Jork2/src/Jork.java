/**
 * The main program that runs the {@link GameManager}
 * @author andyh
 * @version 1.0
 */
public class Jork {

    public static void main(Description[] args) {
        System.out.println("Starting Jork...");
    }
}
